var config = module.exports;

config["My tests"] = {
    environment: "node",
    tests: [
        "*-test.js"
    ]
};
